<html>
<body>
 

    <a href="/Daftar_Game"> Beranda</a>
	
	<br/>
	<br/>
    
	<br/>
	<form action="/revvv" method="post">
    <?php echo e(csrf_field()); ?>

		bulans <input type="char" name="bulans" required="required"> <br/>
		<input type="submit" value="Masukkan Tanggal">
	</form>
	
	<br/>
    <br/>

 
 
</body>
</html><?php /**PATH C:\xampp\htdocs\FP_MBD\resources\views/penghasilan.blade.php ENDPATH**/ ?>