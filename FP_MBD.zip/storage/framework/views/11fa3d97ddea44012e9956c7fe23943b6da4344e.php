<!DOCTYPE html>

<html>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/style.css')); ?>">
<body>
 
	<a href="/Daftar_Game"> Beranda</a>
	
	<br/>
	<br/>
 
	<div class="container">
  		<div class="card">
   			<div class="card-body">

    			<table class="table table-bordered">
		<tr>
			<th>NAMA GAME</th>
		</tr>
		<?php $__currentLoopData = $reviewedgame; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($p->nama_game); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
 
		</div>
  	</div>
</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\FP_MBD\resources\views/reviewedgame.blade.php ENDPATH**/ ?>