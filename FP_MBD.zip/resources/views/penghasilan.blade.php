<html>
<body>
 

    <a href="/Daftar_Game"> Beranda</a>
	
	<br/>
	<br/>
    
	<br/>
	<form action="/revvv" method="post">
    {{ csrf_field() }}
		bulans <input type="char" name="bulans" required="required"> <br/>
		<input type="submit" value="Masukkan Tanggal">
	</form>
	
	<br/>
    <br/>

 
 
</body>
</html>